# IP Range Ping Tool (VBScript)

This VBScript-based tool allows users to ping a range of IP addresses from a specified source IP. It is designed for use in Windows environments and provides a simple interface to test connectivity across a subnet.

## Features

- Ping a range of IPs (e.g., 192.168.1.1-192.168.1.20)
- Specify source IP for outbound pings
- Displays results in a categorized format: Success, Unreachable, Failed
- Lightweight and easy to integrate into HTA or HTML applications

## Getting Started

1. Clone or download the repository.
2. Open the HTA or HTML file containing the VBScript.
3. Enter the source IP and IP range.
4. Click the "Ping" button to begin scanning.

## Requirements

- Windows operating system
- VBScript support (enabled by default)
- Administrator privileges may be required depending on network configuration

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Contributing

Contributions are welcome. Feel free to fork the repository, submit pull requests, or open issues for enhancements or bug fixes.

## Contact

For questions or suggestions, open an issue or reach out via GitHub.
